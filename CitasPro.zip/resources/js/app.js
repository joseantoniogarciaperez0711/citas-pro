// resources/js/app.js
import './bootstrap'

// Alpine (Jetstream ya lo usa; si ya lo tienes, esto no rompe)
import Alpine from 'alpinejs'
window.Alpine = Alpine
Alpine.start()
