<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['class' => 'h-9 w-auto']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['class' => 'h-9 w-auto']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if(auth()->guard()->check()): ?>
    <?php if(auth()->user()->business_logo_path): ?>
        <img
            src="<?php echo e(auth()->user()->business_logo_url); ?>?v=<?php echo e(optional(auth()->user()->updated_at)->timestamp); ?>"
            alt="<?php echo e(config('app.name')); ?>"
            class="<?php echo e($class); ?> rounded-lg object-cover"
        >
    <?php else: ?>
        
        <?php echo e($slot ?? ''); ?>

    <?php endif; ?>
<?php else: ?>
    
    <?php echo e($slot ?? ''); ?>

<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\CitasPro\resources\views/components/application-logo.blade.php ENDPATH**/ ?>