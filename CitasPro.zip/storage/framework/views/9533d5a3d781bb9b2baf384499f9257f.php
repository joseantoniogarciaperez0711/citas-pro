<?php $__env->startComponent('mail::message'); ?>
<?php echo new \Illuminate\Support\EncodedHtmlString(__('You have been invited to join the :team team!', ['team' => $invitation->team->name])); ?>


<?php if(Laravel\Fortify\Features::enabled(Laravel\Fortify\Features::registration())): ?>
<?php echo new \Illuminate\Support\EncodedHtmlString(__('If you do not have an account, you may create one by clicking the button below. After creating an account, you may click the invitation acceptance button in this email to accept the team invitation:')); ?>


<?php $__env->startComponent('mail::button', ['url' => route('register')]); ?>
<?php echo new \Illuminate\Support\EncodedHtmlString(__('Create Account')); ?>

<?php echo $__env->renderComponent(); ?>

<?php echo new \Illuminate\Support\EncodedHtmlString(__('If you already have an account, you may accept this invitation by clicking the button below:')); ?>


<?php else: ?>
<?php echo new \Illuminate\Support\EncodedHtmlString(__('You may accept this invitation by clicking the button below:')); ?>

<?php endif; ?>


<?php $__env->startComponent('mail::button', ['url' => $acceptUrl]); ?>
<?php echo new \Illuminate\Support\EncodedHtmlString(__('Accept Invitation')); ?>

<?php echo $__env->renderComponent(); ?>

<?php echo new \Illuminate\Support\EncodedHtmlString(__('If you did not expect to receive an invitation to this team, you may discard this email.')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\citas\resources\views/emails/team-invitation.blade.php ENDPATH**/ ?>