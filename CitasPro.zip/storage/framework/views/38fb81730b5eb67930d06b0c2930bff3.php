<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['class' => 'h-9 w-auto']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['class' => 'h-9 w-auto']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<!--[if BLOCK]><![endif]--><?php if(auth()->guard()->check()): ?>
    <!--[if BLOCK]><![endif]--><?php if(Auth::user()->business_logo_path): ?>
        <img src="<?php echo e(Auth::user()->business_logo_url); ?>?v=<?php echo e(optional(Auth::user()->updated_at)->timestamp); ?>" alt="Logo"
            <?php echo e($attributes->merge(['class' => $class . ' rounded-lg object-cover'])); ?>>
    <?php else: ?>
        
        <svg <?php echo e($attributes->merge(['class' => $class])); ?> viewBox="0 0 48 48" fill="none"
            xmlns="http://www.w3.org/2000/svg">
            
        </svg>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php else: ?>
    
    <svg <?php echo e($attributes->merge(['class' => $class])); ?> viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
        
        <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
            <path
                d="M11.395 44.428C4.557 40.198 0 32.632 0 24 0 10.745 10.745 0 24 0a23.891 23.891 0 0113.997 4.502c-.2 17.907-11.097 33.245-26.602 39.926z"
                fill="#6875F5" />
            <path
                d="M14.134 45.885A23.914 23.914 0 0024 48c13.255 0 24-10.745 24-24 0-3.516-.756-6.856-2.115-9.866-4.659 15.143-16.608 27.092-31.75 31.751z"
                fill="#6875F5" />
        </svg>
    </svg>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH C:\xampp\htdocs\CitasPro\resources\views/components/application-mark.blade.php ENDPATH**/ ?>